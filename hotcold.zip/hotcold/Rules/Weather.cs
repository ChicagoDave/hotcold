﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Epsilon.Rules
{
    public enum Weather
    {
        Hot,
        Cold
    }
}
