﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Epsilon.Rules
{
    public class ClothingResponse
    {
        public bool IsSuccessful { get; set; }
        public string Response { get; set; }
    }
}
